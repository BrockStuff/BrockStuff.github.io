DOOM WAD SETUP:

BEFORE STARTING!!!!
These WADs have the UZDoom Source Port in mind. You can try other ports with these WADs but UZ is the reccomended version for these WADS. MAKE SURE YOU HAVE A DOOM2.WAD FILE FOR THIS, YOU WILL NEED TO BUY DOOM 2 IN SOME WAY (Doom + Doom II is a working WAD)

Setting up is simple
1. Find your UZDoom Directory
2. Put your WAD in there
3. Drag your WAD onto the UZDoom executable
4. Pick DOOM 2 from the options of game file to run (this is just getting Doom 2 files from the original game)
5. Start

Best of luck, any questions, my socials are pretty open to all to chatter with.