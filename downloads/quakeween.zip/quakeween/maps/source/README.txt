======= MAP SOURCE FILES =======

Heyoo, if you've managed to get yourself here, you found the secret .map files!

These are files containing the raw uncompiled maps found in this PAK. They are here for you to modify to your hearts content!

======= LICENSE =======
CC BY 4.0

You are allowed to share a version of this map (and by extention, map 1's audio track) in any way, shape or form and modify it to your hearts content. However you need to provide me credit for the map's creation & design, alongside the background audio for map 1 (Qarsqe).

Something simple should be easy to write down, structured as; '{map name} created by Brock' with a link to the PAK, wherever you discovered it.

https://creativecommons.org/licenses/by/4.0/ <------- More info about Creative Commons for the curious.

======= NOTES =======

- These files were initially valve format, and were made using Trenchbroom, but putting this into a PAK decided that valve format was not a cool thing. So the source .map files are in Standard Format
- I hope you enjoy the maps themselves, it was meant to be in a bigger and greater map PAK, but I couldn't get it done on time. I will post updates on how it goes soon, now that Halloween is not the target for the PAK anymore.
	- {prowoodstuff.bsky.social is the place to see more info & level design related stuff :P}

I hope you enjoy the PAK! Make sure to send me weird and wonderful clips when you can :D

Last Updated: 31/10/2026 @ 9:25pm ACST