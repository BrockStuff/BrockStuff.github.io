SETTING UP QUAKE LEVELS:

1. Make sure you own Quake, Shareware works as well
2. Download both the .bsp & .lit files (or if they're in a PAK, then just get the PAK)
3. If you are using .bsp/.lit files
	3.a. Go to your ID1 Directory
	3.b. Create a 'maps' folder (if one exists, use that)
	3.c. Drag and Drop both files into the folder
	3.d. When you get into Quake, enter the console
	3.e. 'map {Map Name}'

3. If you are using a .PAK
	3.a. Drag and drop the folder into your Quake Base Directory
	3.b. When you get into Quake, enter the console
	3.c. 'game {Map Pack Name}'

Both methods can also use a shortcut to play the maps/game

1. Create a Shortcut
2. Enter its Properties
3. Add '-map {Map Name}' or '-game {Map Pack Name}' to the end of the shortcut path

Best of luck, any questions, my socials are pretty open to all to chatter with.